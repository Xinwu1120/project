# CLIP
pip install git+https://github.com/openai/CLIP.git
